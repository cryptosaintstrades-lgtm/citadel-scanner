# Liquidity Citadel Scanner v34 — Netlify Snapshots + Airtable Push

Upload `citadel_scanner_v32_8_stop_safety_patch.py` to GitHub and replace the existing file with the same name.

Railway start command can stay exactly the same:

```bash
python citadel_scanner_v32_8_stop_safety_patch.py
```

## Required Railway variables

```txt
DISCORD_WEBHOOK_URL=<your full Discord webhook>
AIRTABLE_TOKEN=<your full Airtable PAT>
AIRTABLE_BASE_ID=appSwudFWMM3ETD68
AIRTABLE_SCANNER_TABLE=Scanner
PUSH_SCANNER_ALERTS_TO_AIRTABLE=true
```

Use the exact Airtable table name you are using for the website. If your Railway project already has this variable and scanner alerts are posting correctly, leave it alone.

## New snapshot variables

```txt
NETLIFY_SITE_URL=https://theliquiditycitadel.trade
ENABLE_NETLIFY_SNAPSHOTS=true
SNAPSHOT_INGEST_SECRET=<same secret you added in Netlify, if any>
SNAPSHOT_TIMEFRAME=5m
SNAPSHOT_CANDLE_LIMIT=80
AIRTABLE_SCREENSHOT_FIELD=Screenshot URL
```

If you did not set `SNAPSHOT_INGEST_SECRET` in Netlify, you can leave it blank in Railway too.

## Airtable fields required

```txt
Pair
Direction
Grade
Score
Summary
Entry Zone
Invalidation
Targets
Timeframe
Date
Published
Featured
Screenshot URL
```

The bot still sends Discord alerts. When an alert qualifies, it now:

1. Sends recent candle data to the Netlify snapshot function.
2. Netlify generates/stores the branded chart snapshot in Blobs.
3. Netlify returns a snapshot URL.
4. The bot writes that URL into Airtable's `Screenshot URL` field.
5. The website displays the real generated chart automatically.
