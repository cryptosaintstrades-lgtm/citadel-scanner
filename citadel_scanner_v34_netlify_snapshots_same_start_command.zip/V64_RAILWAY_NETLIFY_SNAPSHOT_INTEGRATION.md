# V64 — Railway Scanner Bot Snapshot Integration

This update wires the Railway scanner bot into the website's v63 Netlify Snapshot Engine.

## What changed

The scanner bot now creates automatic chart snapshots for qualified scanner alerts.

When a Discord alert qualifies, the bot now:

1. Pulls fresh 5m candles for the setup.
2. Sends the candles + scanner setup details to:

```txt
/.netlify/functions/save-scanner-snapshot
```

3. Netlify generates a branded chart SVG and stores it in Netlify Blobs.
4. Netlify returns a public `snapshotUrl`.
5. The bot writes that URL into Airtable's `Screenshot URL` field.
6. The website scanner detail page and case study cards show the real chart automatically.

## Start command

No start command change.

Keep using:

```bash
python citadel_scanner_v32_8_stop_safety_patch.py
```

## New environment variables

Add these in Railway:

```txt
NETLIFY_SITE_URL=https://theliquiditycitadel.trade
ENABLE_NETLIFY_SNAPSHOTS=true
SNAPSHOT_INGEST_SECRET=<same secret as Netlify if you added one>
SNAPSHOT_TIMEFRAME=5m
SNAPSHOT_CANDLE_LIMIT=80
AIRTABLE_SCREENSHOT_FIELD=Screenshot URL
```

The bot also accepts this alternate secret variable name:

```txt
NETLIFY_SNAPSHOT_SECRET=<same secret as Netlify>
```

## Important note

This does not scrape TradingView. It generates an automatic chart snapshot from Blofin candle data and stores it through Netlify. That makes it more reliable than trying to screenshot TradingView directly.

## Expected Railway logs

When working, Railway should show something like:

```txt
Snapshot saved: ETH-USDT -> https://theliquiditycitadel.trade/.netlify/functions/get-scanner-snapshot?key=...
Discord alert sent: ETH-USDT LONG ...
Airtable scanner alert pushed: ETH-USDT LONG ...
```

If Netlify rejects the request because of a secret mismatch, you will see:

```txt
Snapshot save failed: 401 {"ok":false,"error":"Unauthorized."}
```

Fix by making the Railway `SNAPSHOT_INGEST_SECRET` match Netlify's `SNAPSHOT_INGEST_SECRET` exactly.
